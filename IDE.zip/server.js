var ws=require('ws').Server;
var events=require("./serverEvents");
var socketServer;
var portfinder=require('portfinder');//https://github.com/indexzero/node-portfinder
var clientList=[];
portfinder.basePort=8000;




var Cursor=new function Cursor (ID){
	
	
	if(Cursor.CursorSet==undefined){
		Cursor.CursorSet={};
	//	console.log("oy");
	}
	
	function isRegistered(ID){
		return Cursor.CursorSet[ID]!=undefined;
	}
	
	
	
	function validID(ID){
		return ID!=null && ID!=undefined && ID!="SERVER" && ID!="LOCAL";
	}
	
	function UNREGISTER(ID){
		if(validID(ID) && isRegistered(ID)){
			Cursor.CursorSet[ID]=undefined;
		}
	}
	
	
	
	function REGISTER(ID,C){
		//console.log("User registered with ID "+ID)
		//console.log(Cursor.CursorSet);
		Cursor.CursorSet[ID]=C;
	}
	
	
	this.create=function(ID){
		if(!isRegistered(ID)) {
			var Cur=new Cursor(ID);
			
			REGISTER(ID,Cur);
			return Cur;
			
		};
		return null;
	}
	
	if(validID(ID) && !isRegistered(ID)){
		
		var row=-1;
		var index=-1;
		
		this.setPos=function(ROW,POS){
			index=POS;
			row=ROW;
		}
		
		this.getIndex=function(){
			return index;
		}
		
		this.setIndex=function(INDEX){
			index=INDEX;
		}
		
		this.getRow=function(){
			return row;
		}
		
		this.setRow=function(Row){
			row=Row;
		}
		
		this.match=function(ROW,POS){
			return POS==index && ROW==row;
		}
		
		this.isset=function(){
			return row!=-1 && index!=-1;
		}
		
		this.getID=function(){
			return ID;
		}
		
		this.unregister=function(){
			UNREGISTER(ID);
		}
		
		this.getCursorSet=function (){
			return Cursor.CursorSet;
		}
	}else{
		return null;
	}
	
	

}



/*
 * sync improvment 
 * make the server keep track of the position of the client cursors and if a client sends the incorrect postion of its cursor
 * then the server will resync that client in order to makes sure that the cursor postion is the same among all clients
 * 
 * */

portfinder.getPort(function (err, freePort) {
	socketServer=new ws({port:freePort});
	console.log("initiating server at "+freePort+"");
	
	//var a=Cursor.create("test");
	//var b=Cursor.create("test");
	//Cursor.create("0");
	var ID_COUNTER=0;
	
	socketServer.on('connection',function(client){
		console.log("welcome");
		client.listId=clientList.length;
		clientList.push(client);
	
		client.on('message', function (message) {
		
			var messageContext=JSON.parse(message.toString());
			
			messageContext.fun={}; 
			messageContext.fun.sendToAll=function(m){
				var message=JSON.stringify(m);
				message.fun=undefined;
				for(var i=0;i<clientList.length;i++) clientList[i].send(m);
			}
			messageContext.fun.respond=function(m){
				var message=JSON.stringify(m);
				message.fun=undefined;
				client.send(message);
			}
			messageContext.fun.forward=function(m){
				var message=JSON.stringify(m);
				message.fun=undefined;
				for(var i=0;i<clientList.length;i++){
					if(i!=client.listId)clientList[i].send(message);
				}
			}
			
			messageContext.fun.sync_cursor=function(cursor){
				var message={};
				message.Action="OnSyncCursor";
				message.absPos={Row:cursor.getRow(), Col:cursor.getIndex()};
				message.Row=cursor.getRow();
				message.Col=cursor.getIndex();
				message.ID="LOCAL";
				client.send(JSON.stringify(message));
			}
			
			messageContext.fun.reject=function(reason){
				var message={};
				message.Action="OnConnectionRejected";
				message.Reason=reason;
				client.send(JSON.stringify(message));
				setTimeout(function(){
					client.close();
				},1000)
			}
			
			if(client.Cursor==undefined){
				if((client.Cursor=Cursor.create((ID_COUNTER++)+""))==null){
					messageContext.fun.reject("invalid ID");//if(null==client.Cursor=Cursor.create(messageContext.ID))client.fun.
					return 0;
				}
			}
			
			var doSyncCursor=false;
			if(messageContext.absPos!=undefined){
				if(!client.Cursor.isset()|| events[messageContext.Action]==undefined){
					//if position of the cursor has not yet been set then set the position
					client.Cursor.setPos(messageContext.absPos.Row,messageContext.absPos.Col);
				}else if(((messageContext.absPos.Col!=client.Cursor.getIndex() || messageContext.absPos.Row!=client.Cursor.getRow()))){
					//console.log(messageContext.Action);
					doSyncCursor=true;
					console.log("this "+messageContext.Col+" vs "+client.Cursor.getIndex());
					messageContext.absPos.Row=client.Cursor.getRow();
					messageContext.absPos.Col=client.Cursor.getIndex();
					messageContext.Row=client.Cursor.getRow();
					messageContext.Col=client.Cursor.getIndex();
					
				}
			}
			
			messageContext.fun.Cursor=client.Cursor;
			
			events.passToEvents(messageContext,client);	
			
			
			if(doSyncCursor){
				events.OnFullSync(null,messageContext.fun);
				messageContext.fun.sync_cursor(client.Cursor);
				
			}	
		});

		client.on('close',function close(){
			if(this.Cursor!=undefined)this.Cursor.unregister();
			for(var i=this.listId+1;i<clientList.length;i++){
				clientList[i].listId--;
			}
			clientList.splice(this.listId,1);
		});
	
	});

});






