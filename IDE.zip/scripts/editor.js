var standardServerPort=8000;
var startingRows=4;
var useServer=true;
var EditorTheme="Test";
var MaxRecursiveCalls=3;//the maximum recursive calls that can be done one the tryCut function



var cursorCounter=0;
var Cursor=function(){
	var cursorID=cursorCounter++;
	var cursor=document.createElement('div');
	cursor.setAttribute("class","cursor");
	var currentNode;
	
	var positionInTextBlock=0;
	
	this.setCursor=function setCursor(node,textPosition){
		cursor.style.top=node.offsetTop+"px";
		if(currentNode!=undefined && currentNode.parentElement!=null && currentNode.getIndex()!=node.getIndex() && currentNode.innerHTML=="")currentNode.parentElement.removeChild(currentNode);
		currentNode=node;
		
		if(textPosition===-1){
			cursor.style.left=(node.offsetLeft+node.scrollWidth)+"px"
			positionInTextBlock=node.innerHTML.length;
		}else{
			strLengthTest.innerHTML=node.innerHTML.substring(0,textPosition);
			cursor.style.left=(node.offsetLeft+strLengthTest.scrollWidth)+"px";
			positionInTextBlock=textPosition;
		}
	};
	this.getNode=function(){
		return currentNode;
	}
	this.getID=function(){
		return cursorID;
	}
	this.getCursorPos=function(){return positionInTextBlock;};
	
	this.setState=function(visibility){cursor.style.visibility=visibility;}
	
	this.getElement=function(){return cursor;};
}

function editTextBlock(node){
	if(localCursor.getNode()!=undefined)localCursor.getNode().focus();
	//node.focus();
}

var rowCount=0;
var localCursor=new Cursor();
var remoteCursor= {};
remoteCursor["LOCAL"]=localCursor;
var theme=new ThemeManager();

/*
 * LOADING/CREATING DOM ELEMENTS
 */
var textField=document.getElementsByClassName("text")[0];
var strLengthTest=document.getElementById("testStringLength");
var textPasteField=document.createElement("textarea");//document.getElementById("pasteField");
textPasteField.id="pasteField";
textField.appendChild(textPasteField);

var rowNumberContainer=document.createElement("div");
rowNumberContainer.setAttribute("id","rowNumberContainer");
textField.appendChild(rowNumberContainer);

var textContainer=document.createElement("div");
textContainer.setAttribute("id","textContainer");
textField.appendChild(textContainer);

var textRow=rowcount=document.createElement('div');
	textRow.setAttribute("class","text_row");

var rowNumber=document.createElement("span");
	rowNumber.setAttribute("class","row_number");
	
	//textRow.appendChild(rowNumber);

var textBlock=document.createElement('span');
	textBlock.setAttribute("class","text_block");
	textBlock.setAttribute("tabindex","-1");//allow the div to focused
	


//http://stackoverflow.com/questions/3656467/is-it-possible-to-focus-on-a-div-using-javascript-focus-function#3656524





/*
 *======================================
 */

window.onload=function(){
	loadDOMExtension();
	theme.loadTheme(EditorTheme);
	bindEvents();
	
	textField.appendChild(localCursor.getElement());
	
	
	for(var i=0;i<startingRows;i++){
		addRow();
	}
	
	localCursor.setCursor(addNewTextBlock(textContainer.children[0],localCursor),0);
	
	
	if(useServer)initSocket();
	
	
}


function addRow(){
	textContainer.appendChildTwice(textRow);
	rowNumberContainer.appendChildTwice(rowNumber);
}

function insertRow(node){
	if(node.nextSibling!=null){
		node.parentElement.insertBeforeTwice(textRow,node.nextSibling);
		rowNumberContainer.appendChildTwice(rowNumber);
	}else
		addRow();
}



function removeRow(node){
	
	node.parentElement.removeChild(node);
	rowNumberContainer.removeChild(rowNumberContainer.firstChild);
}

function addNewTextBlock(Row){
	textBlock.innerHTML="";
	
	Row.appendChildTwice(textBlock);
	return Row.lastChild;
	

}

function splitEditBlock(node,position){
	var newstr=node.innerHTML.substring(position,node.innerHTML.length);//changes when implementing collaboration
	
	node.innerHTML=node.innerHTML.substring(0,position);
	textBlock.innerHTML=newstr;
	var nextNode;
	
	if(node.nextSibling!==undefined&&node.nextSibling!==null){
		
		node.parentElement.insertBeforeTwice(textBlock,node.nextSibling);
		nextNode=node.nextSibling;
	}else{
		node.parentElement.appendChildTwice(textBlock);
		nextNode=node.parentElement.lastChild;
		
		
	}
	setHighlight(node);
	setHighlight(nextNode);
	return nextNode;

}

function mergeTextBlock(Head,Tail){
	if(Head!=null && Tail!=null){
		Head.innerHTML=Head.innerHTML+Tail.innerHTML;
		if(Tail.parentElement!=null)Tail.parentElement.removeChild(Tail);
		setHighlight(Head);
		return Head;
	}
	return null;
}

function ifCanMerge(Head,Tail){
	
	if(Tail!=null && ((!isWhiteSpace(Head.innerHTML.charAt(Head.innerHTML.length-1)) && !isWhiteSpace(Tail.innerHTML.charAt(0))) || (!theme.isKeyword(Tail.innerHTML) && !theme.isKeyword(Head.innerHTML)))){
			//console.log("merge");
			return true;
	}
	return false;
	
	
}





function closeEditBlock(node){
	if(node.value!=""){
		textBlock.innerHTML=node.innerHTML.replace(/</g, "&lt;").replace(/>/g, "&gt;");;
		node.parentElement.insertBeforeTwice(textBlock,node.nextSibling);
		node.parentElement.removeChild(node);
	}else{
		node.parentElement.removeChild(node);
	}
}



function acquireRemoteCursor(ID){
	if(remoteCursor[ID]==undefined){
		remoteCursor[ID]=new Cursor();
		textField.appendChild(remoteCursor[ID].getElement());
	}
		
	return remoteCursor[ID];
}

function getAbsoluteCursorPos(Cursor){
	var index=Cursor.getNode().getIndex();
	var sum=0;
	for(var i=0;i<index;i++){
		sum+=Cursor.getNode().parentElement.children[i].innerHTML.length;
	}
	sum+=Cursor.getCursorPos();
	return{
		Row:Cursor.getNode().parentElement.getIndex(),
		Col:sum
	
	};
}

function setAbsoluteCursorPos(Row,Col,C){
	//console.log("ROW "+Row);
	var textBlock=textContainer.children[Row].children;
	var sum=0;
	for(var i=0;i<textBlock.length;i++){
		//console.log(Col+" vs "+(sum+textBlock[i].innerHTML.length));
		if(Col <= sum+textBlock[i].innerHTML.length){
			C.setCursor(textBlock[i],Col-sum);
			return true;
		}else{
			sum+=textBlock[i].innerHTML.length;
		}
	}
	console.log("failed to set pos");
	return false;
}


function getDefaultEditorTextColor(){
	var color =theme.getDefaultTextColor();
	if(color==undefined) return "#FFFFFF";
	return color;

}

/*function textBlockIsKeyword(node){
	console.log(RGBtoHex(node.style.color)+"    "+getDefaultEditorTextColor())
	if(RGBtoHex(node.style.color)!=getDefaultEditorTextColor())return true;
	return false;
	
}*/

function setHighlight(node){
	var syntaxcolor=theme.getColorHighlight(node.innerHTML.trim());
	if(syntaxcolor!=undefined){
		node.style.color=syntaxcolor;
	}else{
		node.style.color=getDefaultEditorTextColor();
	}

}

function isWhiteSpace(str){
	if(theme.ifIgnoreChar(str))return true;
	if(str.length>0 && str.trim().length===0) return true;
	return false;

}

function RGBtoHex(RGB) {
    if (/^#[0-9A-F]{6}$/i.test(RGB)) return RGB;
    RGB = RGB.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    function Hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + (Hex(RGB[1]) + Hex(RGB[2]) + Hex(RGB[3])).toUpperCase();
}




function tryCutBlock(node,Cursor,recursionLevel){
	if(recursionLevel==undefined)recursionLevel=0;
	var cursorGroup=[];
	for(cursor in remoteCursor){
		//if(remoteCaret[caret].getNode().getIndex()==Caret.getNode().getIndex() && remoteCaret[caret].getNode().parentElement.getIndex()==Caret.getNode().parentElement.getIndex()){
		if(remoteCursor[cursor].getNode().parentElement.getIndex()==Cursor.getNode().parentElement.getIndex()){
			if(Cursor.getID()!=remoteCursor[cursor].getID()){
				cursorGroup.push(remoteCursor[cursor]);
			}
		}
	}
		
	var cursorPos=Cursor.getCursorPos();	
	var words=node.innerHTML.getWords();
	var baseNode=node;
	for(var i=words.length-1;i>=0;i--){
		var word=words[i];
		if(theme.isKeyword(word.string)){
		
			if(true){
				var test=node.getIndex();
				var pos=[];
				var targetNode=[];
				
				for(var n=0;n<cursorGroup.length;n++){//cursor loop
					var index=cursorGroup[n].getNode().getIndex();
					if(test==index){
						if(cursorGroup[n].getCursorPos()>=word.start && cursorGroup[n].getCursorPos() <=word.end){
							if(word.start==0)
								targetNode.push(cursorGroup[n].getNode());//recently change this may cause bugs
							else 
								targetNode.push(1);
			
							pos.push(cursorGroup[n].getCursorPos()-word.start);
						}else if(cursorGroup[n].getCursorPos() > word.end){
							targetNode.push(0);
							pos.push(cursorGroup[n].getCursorPos()-word.end);
						}else{
							targetNode.push(cursorGroup[n].getNode());
							pos.push(cursorGroup[n].getCursorPos());
						}
					}else{
						targetNode.push(cursorGroup[n].getNode());
						pos.push(cursorGroup[n].getCursorPos());
					}
				}
			
			
				node=splitEditBlock(baseNode,word.end);
				Cursor.setCursor(node,-1);
				editTextBlock(node);
					
				
				if(word.start!=0){
					
					var toNode=splitEditBlock(node.previousSibling,word.start);
					for(var n=0;n<cursorGroup.length;n++){//cursor loop		
						if(targetNode[n]==1)
							cursorGroup[n].setCursor(toNode,pos[n]);
						else if(targetNode[n]==0)
							cursorGroup[n].setCursor(node,pos[n]);
						else
							cursorGroup[n].setCursor(targetNode[n],pos[n]);
					}	
				}else{//newla added may cause some bugs
				//	console.log("testing");
					for(var n=0;n<cursorGroup.length;n++){//cursor loop		
						if(targetNode[n]==1)
							cursorGroup[n].setCursor(node.previousSibling,pos[n]);
						else if(targetNode[n]==0)
							cursorGroup[n].setCursor(node,pos[n]);
						else
							cursorGroup[n].setCursor(targetNode[n],pos[n]);
					}
				
				}

				if(cursorPos>=word.start && cursorPos <=word.end){					
					Cursor.setCursor(node.previousSibling,cursorPos-word.start);
					
					editTextBlock(node.previousSibling);
					//node=node.previousSibling;
					
				}else{
					Cursor.setCursor(node,1);
					editTextBlock(node);
				}
				
				
				
					
			}
		}
	}
	cursorPos=Cursor.getCursorPos();
	if(Cursor.getNode().nextSibling!=null && ifCanMerge(Cursor.getNode(),Cursor.getNode().nextSibling)){//merge
		var l=Cursor.getNode().innerHTML.length;
		var test=Cursor.getNode().getIndex();
		var pos=[];
		var targetNode=[];
	
		for(var n=0;n<cursorGroup.length;n++){//cursor loop
			var index=cursorGroup[n].getNode().getIndex();
			if(index==test){
				targetNode.push(Cursor.getNode());
				pos.push(cursorGroup[n].getCursorPos());
			}else if(index==test+1){
				targetNode.push(Cursor.getNode());
				pos.push(cursorGroup[n].getCursorPos()+l);
			}else{
				targetNode.push(cursorGroup[n].getNode());
				pos.push(cursorGroup[n].getCursorPos());
			}
			
		}
		
		
		node=mergeTextBlock(Cursor.getNode(),Cursor.getNode().nextSibling);
		Cursor.setCursor(node,cursorPos);
		
		for(var n=0;n<cursorGroup.length;n++){//cursor loop
			cursorGroup[n].setCursor(targetNode[n],pos[n]);
		}
		
		editTextBlock(node);
		if(recursionLevel<MaxRecursiveCalls)tryCutBlock(Cursor.getNode(),Cursor,++recursionLevel);		
	}
	
	if(Cursor.getNode().previousSibling!=null && ifCanMerge(Cursor.getNode().previousSibling,Cursor.getNode())){//merge
		//console.log("merge2");
		var l=Cursor.getNode().previousSibling.innerHTML.length;
		var test=Cursor.getNode().getIndex();
		
		var pos=[];
		var targetNode=[];
		for(var n=0;n<cursorGroup.length;n++){//cursor loop
			var index=cursorGroup[n].getNode().getIndex();
			if(index==test){
				targetNode.push(Cursor.getNode().previousSibling)
				pos.push(cursorGroup[n].getCursorPos()+l);
			}else{
				targetNode.push(cursorGroup[n].getNode())
				pos.push(cursorGroup[n].getCursorPos());
			}
		}
		
		node=mergeTextBlock(Cursor.getNode().previousSibling,Cursor.getNode());
		//if(cursorPos!=l)
		Cursor.setCursor(node,l+cursorPos);
		for(var n=0;n<cursorGroup.length;n++){//cursor loop
			cursorGroup[n].setCursor(targetNode[n],pos[n]);
		}	
	
		
		editTextBlock(node);
		//console.log(recursionLevel);
		if(recursionLevel<MaxRecursiveCalls)tryCutBlock(Cursor.getNode(),Cursor,++recursionLevel);		
	}

}











/*
 * http://stackoverflow.com/questions/7444451/how-to-get-the-actual-rendered-font-when-its-not-defined-in-css
 * http://stackoverflow.com/questions/118241/calculate-text-width-with-javascript
 * http://www.w3schools.com/tags/canvas_measuretext.asp
 * */

function getStringWidth(node,string) {
	console.log("nnooooooo");
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = getComputedStyle(node)['font-size']+" "+getComputedStyle(node)['font-family'];
    //console.log("hello"+);
    var metrics = context.measureText(string);
    return metrics.width;
}

function getTextWidth(node) {
    // re-use canvas object for better performance
    var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
    var context = canvas.getContext("2d");
    context.font = getComputedStyle(node)['font-size']+" "+getComputedStyle(node)['font-family'];
    var metrics = context.measureText(node.innerHTML);
    return metrics.width;
}




