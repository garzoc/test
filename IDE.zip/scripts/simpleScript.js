

/*
 * http://perfectionkills.com/whats-wrong-with-extending-the-dom/
 * 
 * */

function loadDOMExtension(){
	
	Element.prototype.appendChildren=function(node,count){
		for(var i=0;i<count;i++){
			this.appendChildTwice(node);
		}
	}
	
	Element.prototype.appendChildTwice=function(node){
		
		var newNode=node.cloneNode();
		newNode.innerHTML=node.innerHTML;
		
		node.copyEvents(newNode);
		
		this.appendChild(newNode);
		/*if(newNode.useFocus){
			this.lastChild.focus();
		}*/
	}
	/*
	 * 
	 * http://stackoverflow.com/questions/36635392/how-to-appendchildelement-many-times-the-same-element#36635432
	 * */
	Element.prototype.insertBeforeTwice=function(node,nextSibling){
		var newNode=node.cloneNode();
		newNode.innerHTML=node.innerHTML;
		if(node.boundListeners!==undefined){
			for(k in node.boundListeners){
				newNode.bindEventListener(k,node.boundListeners[k]);
			}

		}
		this.insertBefore(newNode,nextSibling);
	}
	
	Element.prototype.copyEvents=function (node){
		if(this.boundListeners!==undefined){
			for(k in this.boundListeners){
				node.bindEventListener(k,this.boundListeners[k]);
				//console.log("hello");
				//node.boundListeners[k](10);
			}
		}
		for(var i=0;i<this.children.length;i++){
			this.children[i].copyEvents(node.children[i]);
		}
	}
	
	Element.prototype.bindEventListener=function(event,func){
		this.addEventListener(event,func);
		if(this.boundListeners==undefined)this.boundListeners={};
		this.boundListeners[event]=func;

	}
	
	Element.prototype.getIndex=function(){
		var i=0;
		var node=this;
		while((node=node.previousElementSibling)!==null)i++;
		return i;
	}
	
	/*Element.prototype.doFocus=function(){
		this.useFocus=true;
	}*/
	
	String.prototype.insert = function (string,index) {
		if (index > 0)
			return this.substring(0, index) + string + this.substring(index, this.length);
		else
			return string + this;
	}
	
	String.prototype.remove = function (pos,count) {
		return this.substring(0, pos) + this.substring(pos+count, this.length);
		
	}
	
	String.prototype.scanForWord = function (pos) {
		var start=1, end=1;
		if(isWhiteSpace(this.charAt(pos))){
			if((pos-start)>=0&& !isWhiteSpace(this.charAt(pos-start))){
				end=0;
			}else if( (pos+end) <this.length&& !isWhiteSpace(this.charAt(pos+1))){
				start=0;
			}
		}
		for(var i=1;i<this.length;i++){
				if(!isWhiteSpace(this.charAt(pos+end)) && (pos+end) <this.length)end++;
				if(isWhiteSpace(this.charAt(pos+end)) && (pos+end)>pos)end--;
				if(!isWhiteSpace(this.charAt(pos-start)) && (pos-start)>=0)start++;
				if(isWhiteSpace(this.charAt(pos-start)) && (pos-start)<pos)start--;
		}
		
		return {
			string :this.substring(pos-start,pos+end),
			start : pos-start,
			end:pos+end
		};
		
	}
	
	String.prototype.getWords = function () {
		var word_list=[];
		var word={};
		var start=0;		
		for(var i=0;i<this.length;i++){
			if(!isWhiteSpace(this.charAt(i))){
				start=i;
				var n=0;
				for(n=i;n<this.length && !isWhiteSpace(this.charAt(n));n++);
				//console.log(n);
				word.string=this.substring(start,n);
				word.start=start;
				word.end=n;
				word_list.push(word);
				i=n;
				word={};
			}
		}
		//console.log(word_list.length);
		return word_list;
	}
}

