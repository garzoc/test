var socket=null;

function initSocket(){
	//socket=new WebSocket("ws://127.0.0.1:8000/IDE");
	socket=new WebSocket("ws://192.168.1.4:8000/IDE");
	socket.onopen=function(e){
		console.log("Establishing contact");

		send("OnFullSync");
		
	};

	socket.onmessage=function(e){
		//console.log(e.data.length);
		var messageContext=JSON.parse(e.data);
		

		
		if(messageContext.Action!=undefined)
			processMessage(messageContext);
	};

	socket.onclose=function(){
		/*var test=setTimeout(function(){
			initSocket();
			//socket=new WebSocket("ws://192.168.1.4:8000/IDE");
		},1000)*/
		console.log("quit");
	};
}

/*function cloneObject(obj){
	var newObj=new Object;
	if(obj===null) return null;		
	for(k in obj)
		newObj[k]=obj[k];
	return newObj;
}*/

function send(Action,Node,Character){
	var messageContext=new Object;
	messageContext.ID="TESTER";
	messageContext.Action=Action;
	//console.log(Action+" - "+Node);
	if(Node!=null){ 
		messageContext.absPos=getAbsoluteCursorPos(localCursor);
		messageContext.Row=messageContext.absPos.Row;
		messageContext.Col=messageContext.absPos.Col;
		messageContext.textBlockIndex=Node.getIndex();
		messageContext.CursorPosition=localCursor.getCursorPos();
		messageContext.Char=Character;
		//console.log("ME: "+messageContext.absPos.Col);
	}
	
	socket.send(JSON.stringify(messageContext));
}


function processMessage(messageContext){
	if(window[messageContext.Action]!=undefined){
		if(messageContext.Row!=undefined && messageContext.Row!=null){
		
		//	console.log("hello "+messageContext.Row+" - "+messageContext.textBlockIndex);
			//console.log(messageContext.test);
			var row=textContainer.children[messageContext.Row];
			var textBlock=row.children[messageContext.textBlockIndex];
			//console.log(remoteCursor["LOCAL"]);
			var cursor=acquireRemoteCursor(messageContext.ID);
			//console.log("OTHER: "+messageContext.absPos.Col);
			setAbsoluteCursorPos(messageContext.Row,messageContext.absPos.Col,cursor);//new code to set cursor position
			//console.log("NOW: "+getAbsoluteCursorPos(cursor).Col);
			textBlock=cursor.getNode();//new code to set cursor position
			
			//console.log("Row "+textBlock.parentElement.getIndex()+ " index " + textBlock.getIndex())
			//console.log(messageContext.ID);
			cursor.setState("visible");
	
			if(messageContext.Action=="OnAddChar")
				window[messageContext.Action](textBlock,messageContext.Char,cursor);
			else if(messageContext.Action=="OnPaste")
				window[messageContext.Action](textBlock,messageContext.Char,cursor);
			else if(messageContext.Action=="addNewTextBlock")
				window[messageContext.Action](row,cursor);
			else if(messageContext.Action=="OnClick")
				var x;//window[messageContext.Action](textBlock,cursor,messageContext.CursorPosition);//old cursor positionning code use for debugging
			else
				window[messageContext.Action](textBlock,cursor);
				
		}
		if(messageContext.Action=="OnFullSync"){
			window[messageContext.Action](messageContext.Text);
		}

	}else{
			console.log("ERROR: Event "+messageContext.Action+" not found");
	}
}

