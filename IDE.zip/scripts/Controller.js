/*function OnFocus(node,Caret){
	//Caret.setState("visible");
}

function OnBlur(node,Caret){
	//Caret.setState("hidden");
	//if(node!=null && node.innerHTML==="") node.parentElement.removeChild(node);
}*/


function OnFullSync(DATA){

	//console.log(DATA);
	 while(textContainer.firstChild){
		removeRow(textContainer.firstChild);
	 }
	
	//insertRow(textContainer.children[0]);
	addRow();
	var node=textContainer.firstChild;
	var cursor=acquireRemoteCursor("SERVER");
	cursor.setState("hidden");
	
	cursor.setCursor(addNewTextBlock(node,cursor),-1);
	for(var i=0;i<DATA.length;i++){
		node=cursor.getNode();
		for(var n=0;n<DATA[i].length;n++){
			if(DATA[i].charAt(n)==" ")
				OnSpace(node,cursor);
			else if(DATA[i].charAt(n)=="\t")
				OnTab(node,cursor);
			else
				OnAddChar(node,DATA[i].charAt(n),cursor);
			
			node=cursor.getNode();
		}
		OnEnter(node,cursor);
	
	}
}


function OnPaste(node,DATA,Cursor){

	for(var i=0;i<DATA.length;i++){
		//console.log(DATA.charCodeAt(i)+" char is "+DATA.charAt(i));
		if(DATA.charCodeAt(i)!=10){
			OnAddChar(node,DATA.charAt(i),Cursor);
			node=Cursor.getNode();
		}else{
			OnEnter(node,Cursor);
			node=Cursor.getNode();
		}
	}

}


function OnSyncCursor(node,Cursor){
	console.log("Syncing local cursor");
	editTextBlock();
}


function OnClick(node,Cursor,cursorPos){
	Cursor.setCursor(node,cursorPos);
	editTextBlock(node);
}


function OnSpace(node,Cursor){
	var cursorPos=Cursor.getCursorPos();
	node.innerHTML=node.innerHTML.insert(" ",cursorPos);
	
	
	for(cursor in remoteCursor){//cursor loop
		if(Cursor.getID()!= remoteCursor[cursor].getID() && Cursor.getNode().parentElement.getIndex() == remoteCursor[cursor].getNode().parentElement.getIndex() && getAbsoluteCursorPos(remoteCursor[cursor]).Col>=getAbsoluteCursorPos(Cursor).Col){
			if(Cursor.getNode().getIndex()==remoteCursor[cursor].getNode().getIndex())
				OnArrowRight(remoteCursor[cursor].getNode(),remoteCursor[cursor]);
			else
				remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
		}
	}
	
	
	Cursor.setCursor(node,++cursorPos);
	tryCutBlock(node,Cursor);
	setHighlight(node);
}


function OnTab(node,Cursor){
	var cursorPos=Cursor.getCursorPos();	
	node.innerHTML=node.innerHTML.insert("\t",cursorPos);
	
	
	for(cursor in remoteCursor){
		//console.log(cursor);
		if(Cursor.getID()!= remoteCursor[cursor].getID() && Cursor.getNode().parentElement.getIndex() == remoteCursor[cursor].getNode().parentElement.getIndex() && getAbsoluteCursorPos(remoteCursor[cursor]).Col>=getAbsoluteCursorPos(Cursor).Col){
			if(Cursor.getNode().getIndex()==remoteCursor[cursor].getNode().getIndex())
				OnArrowRight(remoteCursor[cursor].getNode(),remoteCursor[cursor]);
			else
				remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
		}
	}
	
	Cursor.setCursor(node,++cursorPos);
	tryCutBlock(node,Cursor);
	setHighlight(node);
	
}

function OnEnter(node,Cursor){
	var oldBaseRowIndex=Cursor.getNode().parentElement.getIndex();
	var oldBaseRow=Cursor.getNode().parentElement;
	
	var oldRow={};
	var oldCol={};
	var oldPos={};
	for(cursor in remoteCursor){//cursor loop
		var r=0;
		if(remoteCursor[cursor].getID()!=Cursor.getID()){
			if((r=remoteCursor[cursor].getNode().parentElement.getIndex()) > Cursor.getNode().parentElement.getIndex()){
				oldCol[cursor]=remoteCursor[cursor].getNode().getIndex();
				oldRow[cursor]=r;
			}else if(r==Cursor.getNode().parentElement.getIndex() && getAbsoluteCursorPos(remoteCursor[cursor]).Col>getAbsoluteCursorPos(Cursor).Col){
				oldCol[cursor]= remoteCursor[cursor].getNode().getIndex()-Cursor.getNode().getIndex();
				oldRow[cursor]=r;
				if(Cursor.getNode().getIndex()==remoteCursor[cursor].getNode().getIndex())
					oldPos[cursor]=remoteCursor[cursor].getCursorPos()-Cursor.getCursorPos();
			}	
		}
	}
	
	
	insertRow(node.parentElement);
	var removeOne=false;
	var nextNode;
	if(Cursor.getCursorPos()==node.innerHTML.length){
		if(node.nextSibling!=null){
			Cursor.setCursor(nextNode=node.nextSibling,0);
			removeOne=true;
		}else{
		
			Cursor.setCursor(nextNode=addNewTextBlock(node.parentElement,Cursor),0);
		}
	}else if(Cursor.getCursorPos==0){
		nextNode=node;
	}else{
		nextNode=splitEditBlock(node,Cursor.getCursorPos());
	}
	//var y=0;
	
	while((nextNode.nextSibling)!=null){
		nextNode=nextNode.nextSibling;
		if(nextNode.previousSibling.innerHTML!=""){
			nextNode.parentElement.nextSibling.appendChildTwice(nextNode.previousSibling);
			nextNode.parentElement.removeChild(nextNode.previousSibling);
		}else removeOne=true;
	}
	if(nextNode.innerHTML!="")//add an else here?
		nextNode.parentElement.nextSibling.appendChildTwice(nextNode.parentElement.lastChild);
	
	if(nextNode.parentElement.nextSibling.firstChild==null){
		Cursor.setCursor(addNewTextBlock(oldBaseRow.nextSibling,Cursor,nextNode),0);
		nextNode=addNewTextBlock(oldBaseRow,0);
	}
		
	Cursor.setCursor(nextNode.parentElement.nextSibling.firstChild,0);
	editTextBlock();
	if(nextNode.parentElement!==null)
		nextNode.parentElement.removeChild(nextNode.parentElement.lastChild);
		
		
	for(index in oldRow){//movie cursor down as a new row is created
		/*console.log("cursor "+index);
			console.log("target row is "+(oldRow[index]+1));
			console.log("newCol "+oldCol[index]);
			console.log("pos is "+remoteCursor[index].getCursorPos());
			console.log("number of children "+textContainer.children[oldRow[index]+1].children.length);/**/
		
		if(textContainer.children[oldRow[index]+1].children.length==oldCol[index])oldCol[index]--;
		if(removeOne && oldRow[index]==oldBaseRowIndex)oldCol[index]--;
		if(oldPos[index]==undefined)
			remoteCursor[index].setCursor(textContainer.children[oldRow[index]+1].children[oldCol[index]],remoteCursor[index].getCursorPos());
		else
			remoteCursor[index].setCursor(textContainer.children[oldRow[index]+1].children[oldCol[index]],oldPos[index]);	
	}
	
	tryCutBlock(Cursor.getNode(),Cursor);
	editTextBlock(node);
	setHighlight(node);
}








function OnBackSpace(node,Cursor){
	
	var oldRow={};
	var oldCol={};
	var oldPos={};
	for(var cursor in remoteCursor){
		var r=0;		
		if(remoteCursor[cursor].getID()!=Cursor.getID()){
			if((r=remoteCursor[cursor].getNode().parentElement.getIndex())==Cursor.getNode().parentElement.getIndex() && getAbsoluteCursorPos(remoteCursor[cursor]).Col>=getAbsoluteCursorPos(Cursor).Col){//recently changed
				if(r>0){
					oldCol[cursor]= (remoteCursor[cursor].getNode().getIndex()+textContainer.children[r-1].children.length);//recently added
					/*if(Caret.getNode().getIndex()!=remoteCaret[caret].getNode().getIndex())//recently removed may cuse of soe bugs
						oldCol[caret]= (remoteCaret[caret].getNode().getIndex()+textContainer.children[r-1].children.length+1);
					else
						oldCol[caret]= (remoteCaret[caret].getNode().getIndex()+textContainer.children[r-1].children.length);*/
				}
				oldRow[cursor]=r;
			}
		}
	}
	var cursorPos=Cursor.getCursorPos();
	if (cursorPos > 0){//step 1
	
		for(var cursor in remoteCursor){//cursor loop
			if(remoteCursor[cursor].getID()!=Cursor.getID() && remoteCursor[cursor].getNode().parentElement.getIndex()==Cursor.getNode().parentElement.getIndex() && getAbsoluteCursorPos(Cursor).Col <= getAbsoluteCursorPos(remoteCursor[cursor]).Col){
				if(Cursor.getNode().getIndex()==remoteCursor[cursor].getNode().getIndex())
					OnArrowLeft(remoteCursor[cursor].getNode(),remoteCursor[cursor]);
				else
					remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
			}
		}
		
		node.innerHTML=node.innerHTML.remove(--cursorPos,1);
		Cursor.setCursor(node,cursorPos);
	}else if(node.previousSibling!=null){//step2
		
		for(var cursor in remoteCursor){//cursor loop
			if(remoteCursor[cursor].getID()!=Cursor.getID() && remoteCursor[cursor].getNode().parentElement.getIndex()==Cursor.getNode().parentElement.getIndex() && getAbsoluteCursorPos(cursor).Col <= getAbsoluteCursorPos(remoteCursor[cursor]).Col){
				remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
			}
		}
		
		cursorPos=node.previousSibling.innerHTML.length;	
		var prevNode=node.previousSibling;
		if(cursorPos>0)
			Cursor.setCursor(prevNode,--cursorPos);
		else
			Cursor.setCursor(prevNode,0);
		prevNode.innerHTML=prevNode.innerHTML.remove(cursorPos,1);
		editTextBlock();
		
	}else if(node.parentElement.previousSibling!=undefined && node.previousSibling==undefined){//step 3
		var parent=node.parentElement;
		/*if(!(parent.previousSibling.children.length>1)){ possibly not necceasary
			//addNewTextBlock(parent.previousSibling,Cursor);	
		}*/
		if(parent.previousSibling.children.length>0)
			node=parent.previousSibling.children[parent.previousSibling.children.length-1];	
		Cursor.setCursor(parent.previousSibling.lastChild,-1);
		editTextBlock(parent.previousSibling.lastChild);
		while(0<parent.children.length){
			if(parent.children[0].innerHTML!="")
				parent.previousSibling.appendChildTwice(parent.children[0]);
			parent.removeChild(parent.children[0]);
		}
		
		for(index in oldRow){//cursor loop
			/*console.log("cursor "+index);
			console.log("target row is "+(oldRow[index]-1));
			console.log("newCol "+oldCol[index]);
			console.log("pos is "+remoteCursor[index].getCursorPos());
			console.log("number of children "+textContainer.children[oldRow[index]-1].children.length);/**/
			if(textContainer.children[oldRow[index]-1].children.length==0){
				addNewTextBlock(textContainer.children[oldRow[index]-1],remoteCusor[index]);
			}else{
				if(textContainer.children[oldRow[index]-1].children.length==oldCol[index]) oldCol[index]--;
				remoteCursor[index].setCursor(textContainer.children[oldRow[index]-1].children[oldCol[index]],remoteCursor[index].getCursorPos());
			}
			
		}
		
		removeRow(parent);
		
		
	}
	for(var cursor in remoteCursor){//cursor loop
		remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
	}
	tryCutBlock(Cursor.getNode(),Cursor);
	editTextBlock(node);
	setHighlight(node);
}





function OnArrowUpDown(node,targetRow,Cursor){
	if(targetRow.children[0]===undefined){
		addNewTextBlock(targetRow,Cursor);
		Cursor.setCursor(targetRow.lastChild,-1);
		editTextBlock(targetRow.lastChild);
		return 0;
	}
			
	var cursorRect=Cursor.getElement().getBoundingClientRect();
	var x2 = cursorRect.left;
	var rect=targetRow.lastChild.getBoundingClientRect();
	var x=rect.left;
	if(x2 > x+targetRow.lastChild.scrollWidth){
		Cursor.setCursor(targetRow.lastChild,-1);
		editTextBlock(targetRow.lastChild);
		return 0
	}
					
	for(var i=0;i<targetRow.children.length;i++){	
		rect = targetRow.children[i].getBoundingClientRect();
		x = rect.left;
					
		if((x2-x) <= (x+node.scrollWidth)){
			Cursor.setCursor(targetRow.children[i],Cursor.getCursorPos());
			editTextBlock(targetRow.children[i]);
			break;
		}
	}
	
}

function OnArrowUp(node,Cursor){
	OnArrowUpDown(node,node.parentElement.previousSibling,Cursor);
	
}

function OnArrowDown(node,Cursor){
	OnArrowUpDown(node,node.parentElement.nextSibling,Cursor);
}

function OnArrowLeft(node,Cursor){
	var cursorPos=Cursor.getCursorPos();
	if (cursorPos > 0) {
		Cursor.setCursor(node,--cursorPos);
	}else if(node.previousSibling!=undefined){
		Cursor.setCursor(node.previousSibling,node.previousSibling.innerHTML.length-1);
		editTextBlock(node.previousSibling);
	}
}


function OnArrowRight(node,Cursor){
	var cursorPos=Cursor.getCursorPos();
	if(cursorPos < node.innerHTML.length) {
		Cursor.setCursor(node,++cursorPos);
	} else if(node.nextSibling!==null){
		Cursor.setCursor(node.nextSibling,1);
		editTextBlock(node.nextSibling);
	}
}

function OnAddChar(node,char,C){
	
	/*var x=window.getSelection();
	for(var s in x){
		console.log(s);
	}*/
	
	
	
	var cursorPos=C.getCursorPos();
	node.innerHTML=node.innerHTML.insert(char,cursorPos);
	
	for(cursor in remoteCursor){
		if(C.getID()!= remoteCursor[cursor].getID() && C.getNode().parentElement.getIndex() == remoteCursor[cursor].getNode().parentElement.getIndex() && getAbsoluteCursorPos(remoteCursor[cursor]).Col>=getAbsoluteCursorPos(C).Col){
			if(C.getNode().getIndex()==remoteCursor[cursor].getNode().getIndex())
				OnArrowRight(remoteCursor[cursor].getNode(),remoteCursor[cursor]);
			else
				remoteCursor[cursor].setCursor(remoteCursor[cursor].getNode(),remoteCursor[cursor].getCursorPos());
		}
	}
	
	
	
	C.setCursor(node,++cursorPos);
	
	
	tryCutBlock(node,C);
	
	setHighlight(node);
	
	
}
